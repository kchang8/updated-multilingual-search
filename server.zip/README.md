## Build Setup

``` bash
# install dependencies
npm install

# run server on port localhost:8081
npm start
```
