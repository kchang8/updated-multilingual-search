module.exports = {
    "extends": "standard"
};